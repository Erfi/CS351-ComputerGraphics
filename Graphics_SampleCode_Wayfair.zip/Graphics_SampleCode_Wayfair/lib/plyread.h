/*
Erfan & Ryan
File: light.h
Date: 2 December 2014
*/
#ifndef __PLYREAD__
#define __PLYREAD__