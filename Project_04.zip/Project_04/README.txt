Erfan Azad
Date: Sep 18 2014
--------------------
In this project we are focusing on scan line fill algorithm for polygons.
