/*
Erfan & Ryan
Date: 4 November 2014
File: bezier.h
*/

#ifndef __BEZIER_H__
#define __BEZIER_H__



#endif
