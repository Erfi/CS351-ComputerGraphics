Erfan Azad
Date: Sep 11 2014
--------------------
Along with the original files in the given package. I have also created a "ppmMethods.h" and "ppmMethods.c" files in include and lib directories also I have changed the makefile files to account for this addition. 
