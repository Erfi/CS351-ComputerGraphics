//
//  circle.c
//  
//
//  Created by Ryan Brandt on 9/22/14.
//
//

#include "circle.h"
void circle set(Circle *c, Point tc, double tr){
   /*initialize to center tc and radius tr.*/
    
}

void circle draw(Circle *c, Image *src, Color p){
    /*draw the circle into src using color p.*/
    
}


void circle drawFill(Circle *c, Image *src, Color p){
/*draw a filled circle into src using color p.*/

}