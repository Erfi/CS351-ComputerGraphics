Erfan Azad
Date: Sep 18 2014
--------------------
All the images for the tasks are in ./images folder.
Although mandelbrot function is working nicely, julia is either not working or I cannot find the set within my window.

For extension i have created a image_fwrite() that can write the images to file using different format using the system calls and convert method.
